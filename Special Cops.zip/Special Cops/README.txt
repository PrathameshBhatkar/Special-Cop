Special Cops
============

Entry in PyWeek #31 <https://pyweek.org/31/>
Name: Prathamesh Anant Bhatkar
Team: 
Members: 


The code is written by Prathamesh Bhatkar.
This artwork is created by me.


DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/



RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.py" file and double-click it.

Otherwise open a terminal / console and "cd" to the game directory and run:
  python run_game.py



HOW TO PLAY THE GAME:

Move the cop by arrow keys.
Press space bar to teleport the theif behind the bars.



LICENSE:

This game Special Cops is placed in the Public Domain.


==============Enjoy The Game======================
